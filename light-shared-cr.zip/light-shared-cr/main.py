import os
import requests

def call_other_service():
  """
  Calls another Cloud Run service.

  Returns:
      The response from the other service.
  """

  # Get the URL of the other service from an environment variable.
  other_service_url = os.environ.get('OTHER_SERVICE_URL')
  if not other_service_url:
    raise ValueError('OTHER_SERVICE_URL environment variable not set.')

  # Make a request to the other service.
  response = requests.get(other_service_url)

  # Check the response status code.
  if response.status_code == 200:
    print('Successfully called other service.')
    print(f'Response: {response.text}')
  else:
    print(f'Error calling other service: {response.status_code}')

if __name__ == '__main__':
  call_other_service()
